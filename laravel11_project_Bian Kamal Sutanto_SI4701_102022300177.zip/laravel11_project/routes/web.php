<?php

use Illuminate\Support\Facades\Route;
use App\Models\Produk;

Route::get('/produk', function () {
    $data = Produk::all();
    return view('produk', ['produk' => $data]);
});
