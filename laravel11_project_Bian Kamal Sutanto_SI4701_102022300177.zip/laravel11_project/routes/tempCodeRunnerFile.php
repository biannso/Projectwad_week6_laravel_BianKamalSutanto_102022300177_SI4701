<?php

use Illuminate\Support\Facades\Route;

Route::get('/projectwad', function () {
    return view('projectwad');
});