<!DOCTYPE html>
<html>
<head>
    <title>Daftar Produk</title>
</head>
<body>
    <h1>Daftar Produk</h1>
    <ul>
        @foreach ($produk as $item)
            <li>{{ $item->nama_produk }} - Rp{{ number_format($item->harga) }}</li>
        @endforeach
    </ul>
</body>
</html>
