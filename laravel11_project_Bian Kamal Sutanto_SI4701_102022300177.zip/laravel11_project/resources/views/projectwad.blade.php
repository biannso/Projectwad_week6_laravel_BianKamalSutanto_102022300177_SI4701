<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup Laravel Project</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background-color: #0b1d36;
            color: #ffffff;
        }

        header {
            background-color: #092338;
            padding: 20px 40px;
            border-bottom: 2px solid #1d3557;
        }

        header h1 {
            margin: 0;
            font-size: 28px;
        }

        main {
            padding: 40px;
        }

        .box {
            background-color: #142b47;
            border-radius: 12px;
            padding: 30px;
            max-width: 600px;
            margin: auto;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .box h2 {
            margin-top: 0;
            color: #a8dadc;
        }

        .box p {
            line-height: 1.6;
            color: #f1faee;
        }

        footer {
            text-align: center;
            padding: 20px;
            font-size: 14px;
            color: #888;
        }
    </style>
</head>
<body>

    <header>
        <h1>Laravel Setup Project</h1>
    </header>

    <main>
        <div class="box">
            <h2>Status Proyek</h2>
            <p>Proyek Laravel telah berhasil disiapkan dan dapat berjalan di <code>127.0.0.1:8000</code>.</p>
            
            <h2>Informasi</h2>
            <p>Framework: Laravel (PHP)</p>
            <p>View File: <code>resources/views/project.blade.php</code></p>
            <p>Routing: <code>routes/web.php</code> mengarahkan ke halaman ini.</p>

            <h2>Keterangan Tugas</h2>
            <p>Halaman ini merupakan bagian dari tugas pengaturan awal (setup) Laravel untuk keperluan pembelajaran pengembangan web menggunakan framework PHP modern.</p>
        </div>
    </main>

    <footer>
        &copy; 2025 - Tugas Laravel Setup | Telkom University
    </footer>

</body>
</html>
